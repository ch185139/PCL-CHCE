# Build Notes / 编译说明

本仓库是第三方基于 PCL（Plain Craft Launcher）源码独立二次创作的修改版 PCL CHCE，
基线为 Meloong-Git/PCL tag 2.14.0.0。许可见根目录 LICENCE（不是 MIT）。

## 云端编译（推荐，本地零占用）

1. 打开仓库 Actions 页，左侧选 `Build PCL CHCE`
2. 点 `Run workflow`，分支选 `main`，运行
3. 变绿后，在该次运行详情页的 Artifacts 区块点 `PCL-CHCE-exe`
4. 下载得到 `PCL-CHCE-exe.zip`，解压即 `PCL CHCE.exe`（单文件，勿附带 dll）

工作流会自动解压仓库根目录的 `PCL-CHCE-source.zip`，整解决方案 Release / Any CPU 生成。
若用 git 推送了完整源码树而非 zip，工作流会自动改用 checkout 出来的源码。

## 本地编译（Windows）

VS 2022（17.8+）+ .NET Framework 4.8 目标包，把 `build.bat` 放在仓库根目录双击，
产物在 `dist\PCL CHCE.exe`。必须 Release：正版购买劝导与赞助劝导仅在
BuildType = Release 时执行。

## 合规

关于页首位保留龙腾猫跃署名与赞助链接、保留 McLaunchPrecheck 的正版购买劝导、
界面主色相保持蓝色、无赞助解锁功能。LICENCE 原样附带，公开源代码。
