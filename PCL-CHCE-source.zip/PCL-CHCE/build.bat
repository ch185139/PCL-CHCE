@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo   PCL CHCE - Release Build (single-file exe)
echo ============================================================
echo.

set "SLN=Plain Craft Launcher 2.sln"
set "EXE=Plain Craft Launcher 2\bin\Plain Craft Launcher 2.exe"
set "DIST=dist"
set "OUTEXE=%DIST%\PCL CHCE.exe"

if not exist "%SLN%" (
  echo [ERROR] Put this .bat in the repo root, next to "Plain Craft Launcher 2.sln".
  goto :fail
)

rem ---------- locate Visual Studio (2022 / 17.8+ recommended) ----------
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo [ERROR] vswhere.exe not found. Install Visual Studio 2022 first.
  goto :fail
)
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild -property installationPath`) do set "VSINSTALLDIR=%%i"
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild -property installationVersion`) do set "VSVER=%%i"
if not defined VSINSTALLDIR (
  echo [ERROR] No Visual Studio with MSBuild found.
  goto :fail
)
set "MSBUILD=%VSINSTALLDIR%\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" (
  echo [ERROR] MSBuild.exe not found at: %MSBUILD%
  goto :fail
)
echo [OK] Visual Studio %VSVER%
echo      %VSINSTALLDIR%
echo      If you see "LangVersion 13.0" or CS8652 errors, update VS to 17.8+.

rem ---------- .NET Framework 4.8 targeting pack ----------
set "REF48=%ProgramFiles(x86)%\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8"
if not exist "%REF48%" (
  echo.
  echo [ERROR] .NET Framework 4.8 Targeting Pack is missing.
  echo         VS Installer ^> Modify ^> Individual components ^> search "4.8 targeting pack".
  goto :fail
)
echo [OK] .NET Framework 4.8 targeting pack found.

rem ---------- 1/4 restore ----------
echo.
echo [1/4] Restoring NuGet packages (needs internet on first run) ...
"%MSBUILD%" "%SLN%" /t:Restore /p:Configuration=Release /p:Platform="Any CPU" /v:minimal /nologo
if errorlevel 1 (
  echo [WARN] Auto restore failed. Open the .sln in VS, right-click the solution,
  echo         choose "Restore NuGet Packages", then run this .bat again.
  goto :fail
)

rem ---------- 2/4 clean ----------
echo.
echo [2/4] Cleaning previous output (all configs share the same bin\) ...
"%MSBUILD%" "%SLN%" /t:Clean /p:Configuration=Release /p:Platform="Any CPU" /v:minimal /nologo
if errorlevel 1 goto :fail

rem ---------- 3/4 build ----------
echo.
echo [3/4] Building Release / Any CPU (whole solution, do NOT build only the main project) ...
"%MSBUILD%" "%SLN%" /p:Configuration=Release /p:Platform="Any CPU" /m /v:minimal /nologo
if errorlevel 1 (
  echo [ERROR] Build failed. Scroll up and fix the FIRST error listed.
  goto :fail
)
if not exist "%EXE%" (
  echo [ERROR] Build succeeded but exe is missing: %EXE%
  goto :fail
)

rem ---------- 4/4 publish ----------
echo.
echo [4/4] Publishing single-file exe ...
if not exist "%DIST%" mkdir "%DIST%"
copy /y "%EXE%" "%OUTEXE%" >nul
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo   DONE
for %%A in ("%OUTEXE%") do echo   Output : %CD%\%OUTEXE%   %%~zA bytes
echo ============================================================
echo.
echo   All DLLs are embedded in this exe (resx + AssemblyResolve).
echo   Copy ONLY this one file into an EMPTY folder and double-click
echo   it to verify. Then send it to your group.
echo.
echo   Release is mandatory: McLaunchPrecheck's purchase / donation
echo   prompts only run when BuildType = Release.
echo.
pause
exit /b 0

:fail
echo.
echo [FAILED] Nothing was published. See the messages above.
pause
exit /b 1
